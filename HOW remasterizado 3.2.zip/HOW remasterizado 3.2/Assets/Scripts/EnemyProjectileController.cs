﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyProjectileController : MonoBehaviour {


    public float speed;

    public PlayerBehaviour player;

    public GameObject impactEffect;

    public float rotationSpeed;
    private killPlayer dmgplayer;
    public int DamageToGive;

    private Rigidbody2D myRb2d;
    // Use this for initialization
    void Start() {
        player = FindObjectOfType<PlayerBehaviour>();
        myRb2d = GetComponent<Rigidbody2D>();
        //dmgplayer.invincible = false;
        if (player.transform.position.x < transform.position.x)
        {
            speed = -speed;
            rotationSpeed = -rotationSpeed;
        }
        
	}
	
	// Update is called once per frame
	void Update () {
        myRb2d.velocity = new Vector2(speed, myRb2d.velocity.y);
        myRb2d.angularVelocity = rotationSpeed;
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if ((other.name == "Player"))
        {
            player.Damage(DamageToGive);
            //dmgplayer.invincible = true;
           // StartCoroutine(player.KnockBack(0.02f, 50f, player.transform.position));
            //Invoke("resetInvulnerability", 1);
        }
        /*Instantiate(transform.position, transform.rotation);*/
        Destroy(gameObject);
    }
    private void resetInvulnerability()
    {
        dmgplayer.invincible = false;
    }

}
