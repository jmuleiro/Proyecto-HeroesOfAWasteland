﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerBehaviour : MonoBehaviour
{
    public float moveSpeed;
    public float jumpHeight;
    public AudioSource deathSound;
    public float respawnDelay;
    private float gravityStore;
    private int validar = 0;
    private PlayerBehaviour player;
    public Rigidbody2D rb2d;
    public Transform groundCheck;
    public float groundCheckRadius;
    //killPlayer dmgplayer;
    public LayerMask whatIsGround;
    private bool grounded;

    public int curHealth;
    public int maxHealth = 10;

    private bool doubleJumped;


    public GameObject deathParticle;
    private Animator anim;

    // Use this for initialization
    void Start()
    {
        curHealth = maxHealth;
        player = FindObjectOfType<PlayerBehaviour>();
        anim = GetComponent<Animator>();
        rb2d = GetComponent<Rigidbody2D>();
    }
    void FixedUpdate()
    {
        grounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, whatIsGround);
    }
    // Update is called once per frame
    void Update()
    {
        if (grounded)
        {
            doubleJumped = false;
        }

        anim.SetBool("grounded", grounded);

        if (Input.GetKeyDown(KeyCode.Space) && grounded)
        {
            Jump();
        }

        if (Input.GetKeyDown(KeyCode.Space) && !grounded && !doubleJumped)
        {
            Jump();
            doubleJumped = true;
        }

        if (Input.GetKey(KeyCode.D))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(moveSpeed, GetComponent<Rigidbody2D>().velocity.y);
        }

        if (Input.GetKey(KeyCode.A))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(-moveSpeed, GetComponent<Rigidbody2D>().velocity.y);
        }
        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            player.moveSpeed = 10;
        }
        if(Input.GetKeyUp(KeyCode.LeftControl))
        {
            player.moveSpeed = 5;
        }        


        anim.SetFloat("speed", Mathf.Abs(GetComponent<Rigidbody2D>().velocity.x));

        //kill
        if (curHealth > maxHealth)
        {
            curHealth = maxHealth;
        }
        if (curHealth <= 0)
        {
            curHealth = 0;
            Die();
        }

        if (transform.position.y < -4)
        {
            Die();
        }

    }
    public void Jump()
    {
        GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.x, jumpHeight);
    }
    public void Damage(int dmg)
    {
        if ((curHealth -= dmg) <= 0)
        {
            curHealth = 0;
        }
        else
        {
            curHealth -= dmg;
            anim.Play("Player_RedFlash");
            deathSound.Play();
        }

    }


    public void Die()
    {
        StartCoroutine("RespawnPlayerCo");
        deathSound.Play();
    }

    public IEnumerator RespawnPlayerCo()
    {
        validar = 1;
        Instantiate(deathParticle, player.transform.position, player.transform.rotation);
        player.enabled = false;
        player.GetComponent<Renderer>().enabled = false;
        gravityStore = player.rb2d.gravityScale;
        player.rb2d.gravityScale = 0f;
        player.rb2d.velocity = Vector2.zero;
        yield return new WaitForSeconds(respawnDelay);
        player.rb2d.gravityScale = gravityStore;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        player.enabled = true;
        player.GetComponent<Renderer>().enabled = true;
    }
    public IEnumerator KnockBack(float knockDur, float knockPwr, Vector3 knockbackDir)
    {
        if (validar == 0)
        {
            float timer = 0;
            while (knockDur > timer)
            {
                timer += Time.deltaTime;
                //rb2d.velocity = new Vector2(0, 0);
                rb2d.AddForce(new Vector3(knockbackDir.x * -50, knockbackDir.y + knockPwr, transform.position.z));
                yield return 0;
            }
        }
        else
        {
            validar = 0;
        }
        


    }
    /*void resetInvulnerability()
    {
        dmgplayer.invincible = false;
    }*/

}
