﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class EnemyPatrol : MonoBehaviour {

    public float moveSpeed;
    public bool moveRight;
    public float jumpHeight;

    public Transform wallCheck;
    public float wallCheckRadius;
    public LayerMask whatIsWall;
    private bool hittingWall;
    public int random;
    private bool notAtEdge;
    public Transform edgeCheck;

    private Rigidbody2D rb2d;

    public int MaxHealth = 40;
    public int curHealth;

    // Use this for initialization
    void Start () {
        curHealth = MaxHealth;
        rb2d = gameObject.GetComponent<Rigidbody2D>();
    }
	
	// Update is called once per frame
	void Update () {
        //float timer = 0;
        //random = Random.Range(2, 10);
        hittingWall = Physics2D.OverlapCircle(wallCheck.position, wallCheckRadius, whatIsWall);
        notAtEdge = Physics2D.OverlapCircle(edgeCheck.position, wallCheckRadius, whatIsWall);
        if (hittingWall || !notAtEdge)
        {
            moveRight = !moveRight;
        }
        if (moveRight)
        {
            transform.localScale = new Vector3(-1f, 1f, 1f);
            rb2d.velocity = new Vector2(moveSpeed, rb2d.velocity.y);
        }
        else{
            transform.localScale = new Vector3(1f, 1f, 1f);
            rb2d.velocity = new Vector2(-moveSpeed, rb2d.velocity.y);
        }

        if (curHealth <= 0)
        {
            Destroy(gameObject);
        }
		
	}

    public void Damage(int damage)
    {
        curHealth -= damage;
        gameObject.GetComponent<Animation>().Play("Player_RedFlash");
    }
}
