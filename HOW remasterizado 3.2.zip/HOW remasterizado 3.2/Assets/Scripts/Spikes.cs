﻿using UnityEngine;
using System.Collections;

public class Spikes : MonoBehaviour
{

    private PlayerBehaviour player;
    private Knockback knock;
    private killPlayer dmgplayer;
    
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerBehaviour>();
        knock = FindObjectOfType<Knockback>();
        dmgplayer = FindObjectOfType<killPlayer>();
        dmgplayer.invincible = false;
    }
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("Player"))
        {
           if (dmgplayer.invincible == false)
           {
                player.Damage(1);
                dmgplayer.invincible = true;
                StartCoroutine(player.KnockBack(0.02f, 1500f, player.transform.position));
                Invoke("resetInvulnerability", 1);
           }
            if (col.CompareTag("Ground"))
            {
                Destroy(gameObject);
            }

        }
    }
    void OnTriggerStay2D(Collider2D col)
    {
        if (col.CompareTag("Player"))
        {
            if (dmgplayer.invincible == false)
            {
                player.Damage(1);
                dmgplayer.invincible = true;
                StartCoroutine(player.KnockBack(0.02f, 50f, player.transform.position));
                Invoke("resetInvulnerability", 1);
            }
        }
    }
    private void resetInvulnerability()
    {
        dmgplayer.invincible = false;
    }
    
}
