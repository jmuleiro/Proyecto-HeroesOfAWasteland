﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generate : MonoBehaviour {

    public GameObject GroundTiles;
    public GameObject RockTiles;
    public GameObject BoardTiles;
    public GameObject coinTiles;
    public GameObject enemyTiles;
    public GameObject spikesPrefab;
    public GameObject EndLevel;


    public int width;
    public float heightMultiplier;
    public int heightAddition;

    public float smoothness;

    private Vector2 spawnPosition;
    private PlayerBehaviour player;

    float seed;
	// Use this for initialization
	void Start () {
        seed = Random.Range(-1000f, 1000f);
        player = FindObjectOfType<PlayerBehaviour>();
        generate();
        
	}

    void Spawn(GameObject objeto ,float altura, float lar)
    {
        spawnPosition.x = lar;
        spawnPosition.y = altura + 1;
        Instantiate(objeto, spawnPosition, Quaternion.identity);
    }
    public void generate()
    {
        for (int i = 0; i < width; i++)
        {
            int h = Mathf.RoundToInt(Mathf.PerlinNoise(seed, i / smoothness) * heightMultiplier) + heightAddition;

            for (int j = 0; j < h; j++)
            {
                GameObject selectedTile;
                if (j < h - 4)
                {
                    selectedTile = BoardTiles;
                }
                else if (j < h - 1)
                {
                    selectedTile = RockTiles;
                }
                else
                {
                    selectedTile = GroundTiles;
                    for (int rep = 0; rep < 2; rep++)
                    {
                        int v = Random.Range(0, width);
                        if (i == v && i != 1 && i != 2) { Spawn(enemyTiles, j, i); }
                        int w = Random.Range(0, width);
                        if (i == w && i != 1 && i != 2) { Spawn(coinTiles, j, i); }
                        int x = Random.Range(0, width);
                        if (i == x && i != 1 && i != 2) { Spawn(spikesPrefab, j + 0.1f, i); }
                    }
                    if (i == 1)
                    {
                        player.transform.position = new Vector2(i+1, j+2);
                    }
                    if (i == width - 1)
                    {
                        Instantiate(EndLevel, new Vector2(i, j), Quaternion.identity);
                    }
                }
                Instantiate(selectedTile, new Vector2(i, j), Quaternion.identity);
            }            
        }       

    }
}
