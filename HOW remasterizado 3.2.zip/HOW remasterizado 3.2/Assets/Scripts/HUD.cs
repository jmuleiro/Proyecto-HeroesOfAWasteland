﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HUD : MonoBehaviour {

	public Sprite[] HeartSprites;

	public Image HeartUI;

	private PlayerBehaviour player;

	void Start(){

		player = GameObject.FindGameObjectWithTag ("Player").GetComponent<PlayerBehaviour> ();
	}

	void Update(){
        if(player.curHealth == 10 || player.curHealth == 9)
		HeartUI.sprite = HeartSprites [5];
        if (player.curHealth == 8 || player.curHealth == 7)
            HeartUI.sprite = HeartSprites[4];
        if (player.curHealth == 6 || player.curHealth == 5)
            HeartUI.sprite = HeartSprites[3];
        if (player.curHealth == 4 || player.curHealth == 3)
            HeartUI.sprite = HeartSprites[2];
        if (player.curHealth == 2 || player.curHealth == 1)
            HeartUI.sprite = HeartSprites[1];
        if (player.curHealth <= 0)
            HeartUI.sprite = HeartSprites[0];
    }
}
