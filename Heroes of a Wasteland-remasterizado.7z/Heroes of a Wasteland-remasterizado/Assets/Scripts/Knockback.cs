﻿using UnityEngine;
using System.Collections;

public class Knockback : MonoBehaviour
{

    private Rigidbody2D rb2d;

    // Use this for initialization
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {

    }
   /* public void Knock()
    {
        StartCoroutine("Knockback");
    }*/
    public IEnumerator KnockBack(float knockDur, float knockPwr, Vector3 knockbackDir)
    {
        float timer = 0;
        while (knockDur > timer)
        {
            timer += Time.deltaTime;
            //rb2d.velocity = new Vector2(0, 0);
            rb2d.AddForce(new Vector3(knockbackDir.x * -100, knockbackDir.y + knockPwr, transform.position.z));
        }
        yield return 0;
    }
}