﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class killPlayer : MonoBehaviour {

    public PlayerBehaviour player;
    public bool invincible = false;
    private Rigidbody2D rb2d;

    // Use this for initialization
    void Start() {
        player = FindObjectOfType<PlayerBehaviour>();
        rb2d = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerEnter2D(Collider2D other)
    {

        if (!invincible)
        {
            if (other.name == "Player")
            {
                player.Damage(1);
                //StartCoroutine(Knockback(0.02f, 350, player.transform.position));
                invincible = true;
                Invoke("resetInvulnerability", 1);
            }
            
        }
    }
    void resetInvulnerability()
    {
        invincible = false;
    }
    

}
