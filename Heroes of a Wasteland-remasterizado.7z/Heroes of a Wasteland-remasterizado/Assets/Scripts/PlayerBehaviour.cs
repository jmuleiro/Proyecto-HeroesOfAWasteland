﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerBehaviour : MonoBehaviour {
    public float moveSpeed;
    public float jumpHeight;
    public float respawnDelay;
    private float gravityStore;

    private PlayerBehaviour player;
    private Rigidbody2D rb2d ;
    public Transform groundCheck;
    public float groundCheckRadius;
    public LayerMask whatIsGround;
    private bool grounded;

    public int curHealth;
    public int maxHealth = 5;

    private bool doubleJumped;
    

    public GameObject deathParticle;
    private Animator anim;

    // Use this for initialization
    void Start () {
        curHealth = maxHealth;
        player = FindObjectOfType<PlayerBehaviour>();
        anim = GetComponent<Animator>();
        rb2d = GetComponent<Rigidbody2D>();
    }
	void FixedUpdate()
    {
        grounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, whatIsGround);
    }
	// Update is called once per frame
	void Update () {

        if (grounded)
        {
            doubleJumped = false;
        }

        anim.SetBool("grounded", grounded);

        if (Input.GetKeyDown(KeyCode.Space) && grounded)
        {
            Jump();
        }

        if (Input.GetKeyDown(KeyCode.Space) && !grounded && !doubleJumped)
        {
            Jump();
            doubleJumped = true;
        }

        if (Input.GetKey(KeyCode.D))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(moveSpeed, GetComponent<Rigidbody2D>().velocity.y);
        }

        if (Input.GetKey(KeyCode.A))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(-moveSpeed, GetComponent<Rigidbody2D>().velocity.y);
        }
        

        anim.SetFloat("speed", Mathf.Abs(GetComponent<Rigidbody2D>().velocity.x));

        //kill
        if (curHealth > maxHealth)
        {
            curHealth = maxHealth;
        }

        if (curHealth <= 0)
        {
            curHealth = 0;
            Die();
        }

        if (transform.position.y < -4)
        {
            Die();
        }

    }
    public void Jump()
    {
        GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.x, jumpHeight);
    }

    /*public IEnumerator Knockback(float knockDur, float knockPwr, Vector3 knockbackDir)
    {
        float timer = 0;
        while (knockDur > timer)
        {
            timer += Time.deltaTime;
            rb2d.AddForce(new Vector3(knockbackDir.x * -100, knockbackDir.y * knockPwr, transform.position.z));
        }
        yield return 0;
    }*/
    public void Damage(int dmg)
    {
        if ((curHealth -= dmg) <= 0)
        {
            curHealth = 0;
        }
        else
        {
            curHealth -= dmg;
            anim.Play("Player_RedFlash");
        }

    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("Spikes") || col.CompareTag("Enemy"))
        {
            rb2d.AddForce(Vector3.left * 10);
        }
    }
    
    public void Die()
    {
        StartCoroutine("RespawnPlayerCo");
                //reinicia        
    }   

    public IEnumerator RespawnPlayerCo()
    {
        Instantiate(deathParticle, player.transform.position, player.transform.rotation);
        player.enabled = false;
        player.GetComponent<Renderer>().enabled = false;        
        gravityStore = player.GetComponent<Rigidbody2D>().gravityScale;
        player.GetComponent<Rigidbody2D>().gravityScale = 0f;
        player.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
        yield return new WaitForSeconds(respawnDelay);
        player.GetComponent<Rigidbody2D>().gravityScale = gravityStore;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        player.enabled = true;
        player.GetComponent<Renderer>().enabled = true;
    }
}
