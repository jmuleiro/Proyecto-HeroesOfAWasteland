﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class killPlayer : MonoBehaviour {

    public PlayerBehaviour player;
    public bool invincible = false;
    private Rigidbody2D rb2d;

    // Use this for initialization
    void Start() {
        player = FindObjectOfType<PlayerBehaviour>();
        rb2d = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerStay2D(Collider2D other)
    {

        if (!invincible)
        {
            if (other.name == "Player")
            {
                player.Damage(1);
                invincible = true;
                Invoke("resetInvulnerability", 1f);
            }
            
        }
    }
    void resetInvulnerability()
    {
        invincible = false;
    }
    

}
