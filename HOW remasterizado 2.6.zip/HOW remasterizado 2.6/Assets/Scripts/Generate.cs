﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generate : MonoBehaviour {

    public GameObject GroundTiles;
    public GameObject RockTiles;
    public GameObject BoardTiles;


    public int width;
    public float heightMultiplier;
    public int heightAddition;

    public float smoothness;

    public GameObject coinTiles;                                  //Array of food prefabs.
    public GameObject enemyTiles;                                 //Array of enemy prefabs.

    float seed;
	// Use this for initialization
	void Start () {
            seed = Random.Range(-1000f, 1000f);
            generate();
        
	}

    
    public void generate()
    {
        for (int i = 0; i < width; i++)
        {
            int h = Mathf.RoundToInt(Mathf.PerlinNoise(seed, i / smoothness) * heightMultiplier) + heightAddition;

            for (int j = 0; j < h; j++)
            {
                GameObject selectedTile;
                GameObject enemyGameObject = enemyTiles;
                if (j < h - 4)
                {
                    selectedTile = BoardTiles;
                }
                else if (j < h - 1)
                {
                    selectedTile = RockTiles;
                }
                else
                {
                    selectedTile = GroundTiles;
                    if (i == 3)
                    {
                        Instantiate(enemyGameObject, new Vector2(i + 1, j + 1), Quaternion.identity);
                        Instantiate(coinTiles, new Vector2(i + 1, j + 1), Quaternion.identity);
                    }
                }
                Instantiate(selectedTile, new Vector2(i, j), Quaternion.identity);
            }
        }

    }
}
