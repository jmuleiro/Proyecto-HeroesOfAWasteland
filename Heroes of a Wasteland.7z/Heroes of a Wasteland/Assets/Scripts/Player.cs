﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour {

	//floats
	public float maxSpeed = 3;
	public float speed = 50f;
	public float jumpPower = 150f;

	//bools
	public bool grounded;

	//Stats
	public int curHealth;
	public int maxHealth = 5;

	//References
	private Rigidbody2D rb2d;
	private Animator anim;

	void Start () 
	{
		rb2d = gameObject.GetComponent<Rigidbody2D> ();
		anim = gameObject.GetComponent<Animator> ();

		curHealth = maxHealth;
	}

	void Update ()
	{
		anim.SetBool ("grounded", grounded);
		anim.SetFloat("speed", Mathf.Abs(Input.GetAxis("Horizontal")));

		if (Input.GetAxis ("Horizontal") < 0.1f) 
		{
			transform.localScale = new Vector3 (-1, 1, 1);
		}

		if (Input.GetAxis ("Horizontal") > 0.1f) 
		{
			transform.localScale = new Vector3 (1, 1, 1);
		}

		if (Input.GetButtonDown ("Jump") && grounded) 
		{
			rb2d.AddForce (Vector2.up * jumpPower);
		}

		if (curHealth > maxHealth) {
			curHealth = maxHealth;
		}

		if (curHealth <= 0) {
			Die ();
		}
	}

	void FixedUpdate()
	{

		float h = Input.GetAxis ("Horizontal");

		//moviendo el player
		rb2d.AddForce ((Vector2.right * speed) * h);

		//limitando la velocidad del player
		if (rb2d.velocity.x > maxSpeed) 
		{
			rb2d.velocity = new Vector2 (maxSpeed, rb2d.velocity.y);		
		}

		if (rb2d.velocity.x < -maxSpeed) 
		{

			rb2d.velocity = new Vector2 (-maxSpeed, rb2d.velocity.y);
		}
	}

	void Die(){
		//reinicia
		SceneManager.LoadScene (SceneManager.GetActiveScene ().buildIndex);
	}
}
