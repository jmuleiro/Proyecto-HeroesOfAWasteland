﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generate : MonoBehaviour {

    public GameObject GroundTiles;
    public GameObject RockTiles;
    public GameObject BoardTiles;
    public GameObject coinTiles;
    public GameObject enemyTiles;
    public GameObject spikesPrefab;


    public int width;
    public float heightMultiplier;
    public int heightAddition;

    public float smoothness;

    private Vector2 spawnPosition;
    private PlayerBehaviour player;

    float seed;
	// Use this for initialization
	void Start () {
        seed = Random.Range(-1000f, 1000f);
        player = FindObjectOfType<PlayerBehaviour>();
        generate();
        
	}

    void Spawn(GameObject objeto ,float altura, float lar)
    {
        spawnPosition.x = lar;
        spawnPosition.y = altura + 1;
        Instantiate(objeto, spawnPosition, Quaternion.identity);
    }
    /*void SpawnCoin(int altura, int lar)
    {
        spawnPosition.x = lar;
        spawnPosition.y = altura + 1;
        Instantiate(coinTiles, spawnPosition, Quaternion.identity);
    }*/
    public void generate()
    {
        for (int i = 0; i < width; i++)
        {
            int h = Mathf.RoundToInt(Mathf.PerlinNoise(seed, i / smoothness) * heightMultiplier) + heightAddition;

            for (int j = 0; j < h; j++)
            {
                GameObject selectedTile;
                if (j < h - 4)
                {
                    selectedTile = BoardTiles;
                }
                else if (j < h - 1)
                {
                    selectedTile = RockTiles;                    
                }
                else
                {
                    selectedTile = GroundTiles;
                    int v = Random.Range(0, width);
                    if (i == v && i != 1) { Spawn(enemyTiles, j, i); }
                    int w = Random.Range(0, width);
                    if(i == w && i != 1) {Spawn(coinTiles,j, i); }
                    int x = Random.Range(0, width);
                    if (i == x && i != 1) {Spawn(spikesPrefab, j + 0.2f, i + 0.1f); }
                    if (i == 1)
                    {
                        player.transform.position = new Vector2(i+1, j+1);
                        //for(int k = 0; k < 3; k++) { SpawnEnemy(h); SpawnCoin(h); }
                    }
                }
                Instantiate(selectedTile, new Vector2(i, j), Quaternion.identity);                
                /*Instantiate(enemyTiles, new Vector2(k + 1, j), Quaternion.identity);
                Instantiate(coinTiles, new Vector2(k + 1, j), Quaternion.identity);*/
            }            
        }

    }
}
